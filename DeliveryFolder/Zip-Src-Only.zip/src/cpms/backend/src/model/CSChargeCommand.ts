/**
 * Set of commands that can be used in http requests to identify the action to be performed on a CS
 */
export enum CSChargeCommand {
    startCharge = "start", stopCharge = "stop"
}