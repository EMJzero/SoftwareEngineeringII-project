"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const misc_1 = require("../../src/helper/misc");
const chai_1 = require("chai");
describe("Misc helper module", () => {
    it("should correctly verify a correct URL", () => {
        (0, chai_1.expect)((0, misc_1.checkURL)("https://www.apple.com/something")).to.be.true;
        (0, chai_1.expect)((0, misc_1.checkURL)("http://www.apple.com/something")).to.be.true;
        (0, chai_1.expect)((0, misc_1.checkURL)("http://apple.com/something")).to.be.true;
    });
    it("should not verify a non-URL string", () => {
        (0, chai_1.expect)((0, misc_1.checkURL)("something")).to.be.false;
        (0, chai_1.expect)((0, misc_1.checkURL)("http://apple")).to.be.false;
    });
    it("should not verify non-http URLs", () => {
        (0, chai_1.expect)((0, misc_1.checkURL)("mailto://test.mail@mail.com")).to.be.false;
        (0, chai_1.expect)((0, misc_1.checkURL)("file://Users/test/Desktop/file.txt")).to.be.false;
    });
    it("should correctly replace URLs", () => {
        const testObject = {
            foo: "bar",
            some: Date(),
            child: [{
                    bar: "Hellow",
                    hereURL: "https://www.apple.com/something/something.jpg",
                    otherChild: {
                        otherURL: "https://www.some.thing/object.png"
                    }
                }]
        };
        console.log(testObject);
        (0, misc_1.replaceResourceURLs)(testObject);
        console.log(testObject);
        (0, chai_1.expect)(testObject).to.be.eql({
            foo: "bar",
            some: testObject.some,
            child: [{
                    bar: "Hellow",
                    hereURL: "INSERT_NEW_URL_HERE",
                    otherChild: {
                        otherURL: "INSERT_NEW_URL_HERE"
                    }
                }]
        });
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWlzYy50ZXN0LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsibWlzYy50ZXN0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUEsZ0RBQXNFO0FBQ3RFLCtCQUE4QjtBQUU5QixRQUFRLENBQUMsb0JBQW9CLEVBQUUsR0FBRyxFQUFFO0lBRWhDLEVBQUUsQ0FBQyx1Q0FBdUMsRUFBRSxHQUFHLEVBQUU7UUFDN0MsSUFBQSxhQUFNLEVBQUMsSUFBQSxlQUFRLEVBQUMsaUNBQWlDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDO1FBQy9ELElBQUEsYUFBTSxFQUFDLElBQUEsZUFBUSxFQUFDLGdDQUFnQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQztRQUM5RCxJQUFBLGFBQU0sRUFBQyxJQUFBLGVBQVEsRUFBQyw0QkFBNEIsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7SUFDOUQsQ0FBQyxDQUFDLENBQUM7SUFFSCxFQUFFLENBQUMsb0NBQW9DLEVBQUUsR0FBRyxFQUFFO1FBQzFDLElBQUEsYUFBTSxFQUFDLElBQUEsZUFBUSxFQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7UUFDMUMsSUFBQSxhQUFNLEVBQUMsSUFBQSxlQUFRLEVBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztJQUNqRCxDQUFDLENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQyxpQ0FBaUMsRUFBRSxHQUFHLEVBQUU7UUFDdkMsSUFBQSxhQUFNLEVBQUMsSUFBQSxlQUFRLEVBQUMsNkJBQTZCLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDO1FBQzVELElBQUEsYUFBTSxFQUFDLElBQUEsZUFBUSxFQUFDLG9DQUFvQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztJQUN2RSxDQUFDLENBQUMsQ0FBQztJQUVILEVBQUUsQ0FBQywrQkFBK0IsRUFBRSxHQUFHLEVBQUU7UUFDckMsTUFBTSxVQUFVLEdBQUc7WUFDZixHQUFHLEVBQUUsS0FBSztZQUNWLElBQUksRUFBRSxJQUFJLEVBQUU7WUFDWixLQUFLLEVBQUUsQ0FBQztvQkFDSixHQUFHLEVBQUUsUUFBUTtvQkFDYixPQUFPLEVBQUUsK0NBQStDO29CQUN4RCxVQUFVLEVBQUU7d0JBQ1IsUUFBUSxFQUFFLG1DQUFtQztxQkFDaEQ7aUJBQ0osQ0FBQztTQUNMLENBQUM7UUFDRixPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3hCLElBQUEsMEJBQW1CLEVBQUMsVUFBVSxDQUFDLENBQUM7UUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUN4QixJQUFBLGFBQU0sRUFBQyxVQUFVLENBQUMsQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQztZQUN6QixHQUFHLEVBQUUsS0FBSztZQUNWLElBQUksRUFBRSxVQUFVLENBQUMsSUFBSTtZQUNyQixLQUFLLEVBQUUsQ0FBQztvQkFDSixHQUFHLEVBQUUsUUFBUTtvQkFDYixPQUFPLEVBQUUscUJBQXFCO29CQUM5QixVQUFVLEVBQUU7d0JBQ1IsUUFBUSxFQUFFLHFCQUFxQjtxQkFDbEM7aUJBQ0osQ0FBQztTQUNMLENBQUMsQ0FBQztJQUNQLENBQUMsQ0FBQyxDQUFDO0FBQ1AsQ0FBQyxDQUFDLENBQUMifQ==