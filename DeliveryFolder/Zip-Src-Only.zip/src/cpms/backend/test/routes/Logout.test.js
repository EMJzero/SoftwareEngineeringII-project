"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = require("chai");
const chaiHttp = require("chai-http");
const sinon_1 = require("sinon");
const sinonChai = require("sinon-chai");
const app_1 = __importDefault(require("../../src/app"));
const authentication_1 = __importDefault(require("../../src/helper/authentication"));
(0, chai_1.use)(chaiHttp);
(0, chai_1.use)(sinonChai);
const sandbox = (0, sinon_1.createSandbox)();
describe("/logout endpoint", () => {
    let requester;
    let checkJWTStub;
    before(() => {
        requester = (0, chai_1.request)(app_1.default.express).keepOpen();
    });
    after(() => {
        requester.close();
    });
    afterEach(() => {
        sandbox.restore();
    });
    describe("GET /", () => {
        it("should succeed", () => __awaiter(void 0, void 0, void 0, function* () {
            checkJWTStub = sandbox.stub(authentication_1.default, "checkJWT");
            checkJWTStub.returns("userId");
            const res = yield requester.get("/logout");
            (0, chai_1.expect)(res).to.have.status(200);
        }));
    });
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiTG9nb3V0LnRlc3QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJMb2dvdXQudGVzdC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7OztBQUFBLCtCQUE0QztBQUM1QyxzQ0FBdUM7QUFDdkMsaUNBQWlEO0FBQ2pELHdDQUF5QztBQUN6Qyx3REFBZ0M7QUFDaEMscUZBQTZEO0FBSTdELElBQUEsVUFBRyxFQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2QsSUFBQSxVQUFHLEVBQUMsU0FBUyxDQUFDLENBQUM7QUFFZixNQUFNLE9BQU8sR0FBRyxJQUFBLHFCQUFhLEdBQUUsQ0FBQztBQUVoQyxRQUFRLENBQUMsa0JBQWtCLEVBQUUsR0FBRyxFQUFFO0lBRTlCLElBQUksU0FBeUIsQ0FBQztJQUM5QixJQUFJLFlBQXVCLENBQUM7SUFFNUIsTUFBTSxDQUFDLEdBQUcsRUFBRTtRQUNSLFNBQVMsR0FBRyxJQUFBLGNBQU8sRUFBQyxhQUFHLENBQUMsT0FBTyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFFSCxLQUFLLENBQUMsR0FBRyxFQUFFO1FBQ1AsU0FBUyxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3RCLENBQUMsQ0FBQyxDQUFDO0lBRUgsU0FBUyxDQUFDLEdBQUcsRUFBRTtRQUNYLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUN0QixDQUFDLENBQUMsQ0FBQztJQUVILFFBQVEsQ0FBQyxPQUFPLEVBQUUsR0FBRyxFQUFFO1FBQ25CLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxHQUFTLEVBQUU7WUFDNUIsWUFBWSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsd0JBQWMsRUFBRSxVQUFVLENBQUMsQ0FBQztZQUN4RCxZQUFZLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxDQUFDO1lBQy9CLE1BQU0sR0FBRyxHQUFHLE1BQU0sU0FBUyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUMzQyxJQUFBLGFBQU0sRUFBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUNwQyxDQUFDLENBQUEsQ0FBQyxDQUFDO0lBQ1AsQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDLENBQUMsQ0FBQyJ9