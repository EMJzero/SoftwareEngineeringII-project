"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.mochaGlobalTeardown = exports.mochaGlobalSetup = void 0;
// import { start, stop } from "mongo-unit";
const dotenv_1 = require("dotenv");
const path_1 = require("path");
// Load environment variables from a testing specif .env file
(0, dotenv_1.config)({ path: (0, path_1.join)(__dirname, ".test.env") });
// Register callbacks that will be executed when loading/unloading the entire testing environment
const mochaGlobalSetup = () => __awaiter(void 0, void 0, void 0, function* () {
    // Start the mongo-unit DB instance.
    // mongo-unit will run a MongoDB instance in memory to simplify and speed up testing
    // process.env.TEST_DB_STRING = await start();
});
exports.mochaGlobalSetup = mochaGlobalSetup;
const mochaGlobalTeardown = () => __awaiter(void 0, void 0, void 0, function* () {
    // Stop the mongo-unit DB instance
    // await stop();
});
exports.mochaGlobalTeardown = mochaGlobalTeardown;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJlcGFyZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbInByZXBhcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsNENBQTRDO0FBQzVDLG1DQUFnQztBQUNoQywrQkFBNEI7QUFFNUIsNkRBQTZEO0FBQzdELElBQUEsZUFBTSxFQUFDLEVBQUUsSUFBSSxFQUFFLElBQUEsV0FBSSxFQUFDLFNBQVMsRUFBRSxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7QUFFL0MsaUdBQWlHO0FBQzFGLE1BQU0sZ0JBQWdCLEdBQUcsR0FBUyxFQUFFO0lBQ3ZDLG9DQUFvQztJQUNwQyxvRkFBb0Y7SUFDcEYsOENBQThDO0FBQ2xELENBQUMsQ0FBQSxDQUFDO0FBSlcsUUFBQSxnQkFBZ0Isb0JBSTNCO0FBRUssTUFBTSxtQkFBbUIsR0FBRyxHQUFTLEVBQUU7SUFDMUMsa0NBQWtDO0lBQ2xDLGdCQUFnQjtBQUNwQixDQUFDLENBQUEsQ0FBQztBQUhXLFFBQUEsbUJBQW1CLHVCQUc5QiJ9