/*
declare module "promisified-pipe" {
    export function promisifiedPipe(input: ReadableStream | GridFSBucketReadStream, output: WritableStream | GridFSBucketWriteStream): Promise<any>
}

 */